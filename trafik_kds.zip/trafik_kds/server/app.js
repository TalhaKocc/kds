const express = require('express');
const app = express();
const cors = require('cors');
const dotenv = require('dotenv');
const cookie = require("cookie-parser");
const path = require("path")

dotenv.config();

const dbService = require('./dbService');
const cookieParser = require('cookie-parser');

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookie())
app.set("view engine", "ejs")
app.set("views", "./views")

const publicDirectoryCss = path.join(__dirname, '../client/css');
const publicDirectoryJs = path.join(__dirname, '../client/js');

app.use('/css', express.static(publicDirectoryCss))
app.use('/js', express.static(publicDirectoryJs));
app.use('/auth/css', express.static(publicDirectoryCss))
app.use('/client', express.static('../client'));

app.use("/", require("./routes/pages"))
app.use("/api", require("./controllers/auth.js"))


app.get('/getAll', (request, response) => {
    const db = dbService.getDbServiceInstance();

    const result = db.getAllData();

    result
    .then(data => response.json({ data: data }))
    .catch(err => console.log(err));
})

app.get('/search/:urun_ad', (request, response) => {
    const { urun_ad } = request.params;
    const db = dbService.getDbServiceInstance();
    
    const result = db.searchByName(urun_ad);

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/kaza_aylar_2021/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_aylar_2021();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/kaza_aylar_2022/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_aylar_2022();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/kaza_turler_2021/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_turler_2021();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/kaza_turler_2022/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_turler_2022();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/kaza_arac_2021/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_arac_2021();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/kaza_arac_2022/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_arac_2022();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/kaza_isik_2021/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_isik_2021();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/kaza_isik_2022/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_isik_2022();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/kaza_yerlesim_2021/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_yerlesim_2021();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/kaza_yerlesim_2022/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_yerlesim_2022();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/kaza_sayisi_2021/', (request, response) => {     
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_sayisi_2021();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})
   
app.get('/kaza_sayisi_2022/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.kaza_sayisi_2022();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/encok_arac_2021/', (request, response) => {
    const db = dbService.getDbServiceInstance();
    
    const result = db.encok_arac_2021();

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})

app.get('/encok_arac_2022/', (request, response) => {       
    const db = dbService.getDbServiceInstance();

    const result = db.encok_arac_2022()

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err))
})

app.get('/encok_ay_2021/', (request, response) => {   
    const db = dbService.getDbServiceInstance();

    const result = db.encok_ay_2021()

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err))
})

app.get('/encok_ay_2022/', (request, response) => {     
    const db = dbService.getDbServiceInstance();

    const result = db.encok_ay_2022()

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err))
})

app.get('/encok_tur_2021/', (request, response) => {     
    const db = dbService.getDbServiceInstance();

    const result = db.encok_tur_2021()

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err))
})

app.get('/encok_tur_2022/', (request, response) => {         
    const db = dbService.getDbServiceInstance();

    const result = db.encok_tur_2022()

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err))
})


app.get('/searchStok/:urun_ad', (request, response) => {
    const { urun_ad } = request.params;
    const db = dbService.getDbServiceInstance();
    
    const result = db.searchStok(urun_ad);

    result
    .then(data => response.json({data : data}))
    .catch(err => console.log(err));
})
   

app.listen(process.env.PORT, () => console.log('app is running'));