const mysql = require('mysql');
const dotenv = require('dotenv');
let instance = null;
dotenv.config();

const connection = mysql.createConnection({
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE,
    port: process.env.DB_PORT
})

connection.connect((err) => {
    if (err) {
        console.log(err.message);
    }
    console.log('Veri tabanina ' + connection.state);
});


class DbService {
    static getDbServiceInstance() {
        return instance ? instance : new DbService();
    }

    async getAllData() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT kaza.kaza_id,kaza_turu.kaza_tur_id,kaza_turu.kaza_tur_adi,araclar.arac_id,araclar.arac_adi,aylar.ay_id,
                aylar.ay_adi,isik.isik_id,isik.isik_adi,yerlesim.yerlesim_id,yerlesim.yerlesim_adi,kaza.yil
                FROM kaza INNER JOIN kaza_turu ON kaza.kaza_tur_id=kaza_turu.kaza_tur_id
                INNER JOIN araclar ON araclar.arac_id=kaza.arac_id
                INNER JOIN aylar ON aylar.ay_id=kaza.ay_id
                INNER JOIN isik ON isik.isik_id=kaza.isik_id
                INNER JOIN yerlesim ON yerlesim.yerlesim_id=kaza.yerlesim_id
                ORDER BY kaza.kaza_id;`;
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            //console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }
    
    async searchByName(urun_ad) {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT urun_id, urun_ad, kategori_ad, renk_ad, urun_olcu
                FROM urunler
                RIGHT JOIN kategori ON urunler.urun_kategori = kategori.kategori_id
                RIGHT JOIN renk ON urunler.renk_id = renk.renk_id
                WHERE urun_ad LIKE ?
                ORDER BY urun_id`;
                connection.query(query, [urun_ad], (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            return response;

        } catch (error) {
            console.log(error);
        }
    }
     
    async kaza_aylar_2021() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT aylar.ay_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM aylar
                LEFT JOIN kaza ON aylar.ay_id = kaza.ay_id 
                WHERE kaza.yil = 2021
                GROUP BY aylar.ay_id
                ORDER BY aylar.ay_id;`;
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async kaza_aylar_2022() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT aylar.ay_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM aylar
                LEFT JOIN kaza ON aylar.ay_id = kaza.ay_id 
                WHERE kaza.yil = 2022
                GROUP BY aylar.ay_id
                ORDER BY aylar.ay_id;`;
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async kaza_turler_2021() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT kaza_turu.kaza_tur_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM kaza INNER JOIN kaza_turu ON kaza.kaza_tur_id=kaza_turu.kaza_tur_id
                WHERE kaza.yil=2021
                GROUP BY kaza_turu.kaza_tur_id;`;
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async kaza_turler_2022() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT kaza_turu.kaza_tur_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM kaza INNER JOIN kaza_turu ON kaza.kaza_tur_id=kaza_turu.kaza_tur_id
                WHERE kaza.yil=2022
                GROUP BY kaza_turu.kaza_tur_id;`;
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async kaza_arac_2021() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT araclar.arac_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM kaza INNER JOIN araclar ON kaza.arac_id=araclar.arac_id
                WHERE kaza.yil=2021
                GROUP BY araclar.arac_id;`;
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async kaza_arac_2022() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT araclar.arac_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM kaza INNER JOIN araclar ON kaza.arac_id=araclar.arac_id
                WHERE kaza.yil=2022
                GROUP BY araclar.arac_id;`;
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async kaza_isik_2021() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT isik.isik_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM kaza INNER JOIN isik ON kaza.isik_id=isik.isik_id
                WHERE kaza.yil=2021
                GROUP BY isik.isik_id;`;

                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }
    
    async kaza_isik_2022() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT isik.isik_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM kaza INNER JOIN isik ON kaza.isik_id=isik.isik_id
                WHERE kaza.yil=2022
                GROUP BY isik.isik_id`;

                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async kaza_yerlesim_2021() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT yerlesim.yerlesim_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM kaza INNER JOIN yerlesim ON kaza.yerlesim_id=yerlesim.yerlesim_id
                WHERE kaza.yil=2021
                GROUP BY yerlesim.yerlesim_id;`;

                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async kaza_yerlesim_2022() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT yerlesim.yerlesim_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM kaza INNER JOIN yerlesim ON kaza.yerlesim_id=yerlesim.yerlesim_id
                WHERE kaza.yil=2022
                GROUP BY yerlesim.yerlesim_id;`;

                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async kaza_sayisi_2021() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT COUNT(kaza.kaza_id) as kaza_sayisi
                FROM kaza
                WHERE kaza.yil=2021;`;
                
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            //console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async kaza_sayisi_2022() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT COUNT(kaza.kaza_id) as kaza_sayisi
                FROM kaza
                WHERE kaza.yil=2022;`;
                
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async encok_arac_2021() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT araclar.arac_adi ,COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM araclar
                INNER JOIN kaza ON araclar.arac_id = kaza.arac_id
                WHERE kaza.yil=2021
                GROUP BY araclar.arac_id
                ORDER BY kaza_sayisi DESC
                LIMIT 5;`;
                
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async encok_arac_2022() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT araclar.arac_adi ,COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM araclar
                INNER JOIN kaza ON araclar.arac_id = kaza.arac_id
                WHERE kaza.yil=2022
                GROUP BY araclar.arac_id
                ORDER BY kaza_sayisi DESC
                LIMIT 5;`;
                
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async encok_ay_2021() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT aylar.ay_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM aylar
                INNER JOIN kaza ON aylar.ay_id = kaza.ay_id
                WHERE kaza.yil=2021
                GROUP BY aylar.ay_id
                ORDER BY kaza_sayisi DESC
                LIMIT 5;`;
                
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async encok_ay_2022() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT aylar.ay_adi, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM aylar
                INNER JOIN kaza ON aylar.ay_id = kaza.ay_id
                WHERE kaza.yil=2022
                GROUP BY aylar.ay_id
                ORDER BY kaza_sayisi DESC
                LIMIT 5;`;
                
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async encok_tur_2021() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT kaza_turu.kaza_tur_adi AS kaza_turu, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM kaza_turu
                INNER JOIN kaza ON kaza_turu.kaza_tur_id = kaza.kaza_tur_id
                WHERE kaza.yil=2021
                GROUP BY kaza_turu.kaza_tur_id 
                ORDER BY kaza_sayisi DESC 
                LIMIT 5;`;
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }

    async encok_tur_2022() {
        try {
            const response = await new Promise((resolve, reject) => {
                const query = `SELECT kaza_turu.kaza_tur_adi AS kaza_turu, COUNT(kaza.kaza_id) AS kaza_sayisi
                FROM kaza_turu
                INNER JOIN kaza ON kaza_turu.kaza_tur_id = kaza.kaza_tur_id
                WHERE kaza.yil=2022
                GROUP BY kaza_turu.kaza_tur_id 
                ORDER BY kaza_sayisi DESC 
                LIMIT 5;`;
                
                connection.query(query, (err, results) => {
                    if (err) reject(new Error(err.message));
                    resolve(results);
                })
            });

            // console.log(response);
            return response;

        } catch (error) {
            console.log(error);
        }
    }



}; 


module.exports = DbService;