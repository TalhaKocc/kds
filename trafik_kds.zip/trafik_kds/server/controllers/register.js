const bcrypt = require("bcryptjs");
const mysql = require('mysql')

const db = mysql.createConnection({
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE,
    port: process.env.DB_PORT
})

const register = async (req, res) => {
    const { username, password:Npassword } = req.body
    if (!username || !Npassword) return res.json({ status : "error", error : "Lütfen kullanıcı adı ve şifre giriniz" });
    else {
        console.log(username)
        db.query('SELECT kullanici_login FROM kullanici WHERE kullanici_login = ?', [username], async (err, result) => {
            if (err) throw err;
            if (result[0]) return res.json({ status : "error", error : "Bu kullanıcı adına bir hesap mevcut." })
            else {
                const password = await bcrypt.hash(Npassword, 8);
                console.log(password)
                db.query('INSERT INTO kullanici SET ?', {kullanici_login:username, kullanici_sifre:password}, (error, results) => {
                    if (error) throw error;
                    return res.json({status : "success", success: "Hesap başarıyla oluşturuldu"}) 
                })
            }
        })
    }
}

module.exports = register;