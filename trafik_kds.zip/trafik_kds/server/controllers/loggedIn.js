const mysql = require('mysql')

const db = mysql.createConnection({
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE,
    port: process.env.DB_PORT
})

const jwt = require('jsonwebtoken')

const loggedIn = (req, res, next) => {
    if (!req.cookies.userRegistered) return next();
    try {
        const decoded = jwt.verify(req.cookies.userRegistered, process.env.JWT_SECRET);
        db.query('SELECT * FROM kullanici WHERE id = ?', [decoded.id], (err, result) => {
            if (err) {
                console.error(err)
                return next()
            }
            req.user = result[0];
            return next();
        })
    } catch (err) {
        console.error(err)
        if (err) return next()
    }
}

module.exports = loggedIn;
