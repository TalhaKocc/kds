const mysql = require("mysql");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");

const db = mysql.createConnection({
    host: process.env.HOST,
    user: process.env.USER,
    password: process.env.PASSWORD,
    database: process.env.DATABASE,
    port: process.env.DB_PORT
});

const login = async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) return res.json({ status: "error", error: "Lütfen kullanıcı adı ve şifre giriniz" });
    else {
        db.query('SELECT * FROM kullanici WHERE kullanici_login = ?', [username], async (Err, result) => {
            if (Err) throw Err;

            console.log("Result:", result); 

            if (!result || result.length === 0) {
                return res.json({ status: "error", error: "Kullanıcı adı ve ya şifre hatalı" });
            }

            const bcryptResult = await bcrypt.compare(password, result[0].kullanici_sifre);
            console.log("bcryptResult:", bcryptResult); 

            if (!bcryptResult) {
                return res.json({ status: "error", error: "Kullanıcı adı ve ya şifre hatalı" });
            } else {
                const token = jwt.sign({ id: result[0].id }, process.env.JWT_SECRET, {
                    expiresIn: process.env.JWT_EXPIRES
                });

                const cookieOptions = {
                    expiresIn: new Date(Date.now() + process.env.COOKIE_EXPIRES * 24 * 60 * 60 * 1000),
                    httpOnly: true
                };

                res.cookie("userRegistered", token, cookieOptions);
                res.redirect("/dashboard");
            }
        });
    }
};

module.exports = login;
