const express = require("express")
const loggedIn = require('../controllers/loggedIn.js')
const logout = require('../controllers/logout')
const router = express.Router()

router.get("/", loggedIn, (req, res) => {
    if (req.user) {
        res.render("dashboard", { status: "loggedIn", user: req.user });
    } else {
        res.render("register", { status: "no", user: "nothing" });
    }
});

// Add a new route for redirecting to the dashboard
router.get("/dashboard", loggedIn, (req, res) => {
    // Check if the user is authenticated
    if (req.user) {
        res.render("dashboard", { status: "loggedIn", user: req.user });
    } else {
        // Redirect to the login page if the user is not authenticated
        res.redirect("/");
    }
});

router.get("/register", (req, res) => {
    res.sendFile("register.html", {root:"../client/"});
})

router.get("/login", (req, res) => {
    res.sendFile("login.html", {root:"../client/"});
})

router.get("/logout", logout)


module.exports = router;