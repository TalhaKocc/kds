  fetch('http://localhost:3000/encok_arac_2021/')
  .then(response => response.json())
  .then(data => { 
    
    var data = data.data

    var options = {
    series: [{
    data: data.map(item => item.kaza_sayisi)
  }],
    chart: {
    type: 'bar',
    height: 350
  },

  title: {
    text: 'En Çok Kaza Yapan Araçlar (2021)  ',
    align: 'left'
  },
  
  plotOptions: {
    bar: {
      borderRadius: 2,
      horizontal: true,
    }
  },
  dataLabels: {
    enabled: false
  },
  xaxis: {
    categories: data.map(item => item.arac_adi)
  }
  };

  var chart = new ApexCharts(document.querySelector("#arac1"), options);
  chart.render(); 
});

fetch('http://localhost:3000/encok_arac_2022/')
  .then(response => response.json())
  .then(data => { 
    
    var data = data.data

    var options = {
    series: [{
    data: data.map(item => item.kaza_sayisi)
  }],
    chart: {
    type: 'bar',
    height: 350
  },

  title: {
    text: 'En Çok Kaza Yapan Araçlar (2022)  ',
    align: 'left'
  },
  
  plotOptions: {
    bar: {
      borderRadius: 2,
      horizontal: true,
    }
  },
  dataLabels: {
    enabled: false
  },
  xaxis: {
    categories: data.map(item => item.arac_adi)
  }
  };

  var chart = new ApexCharts(document.querySelector("#arac2"), options);
  chart.render(); 
});

fetch('http://localhost:3000/encok_ay_2021/')
  .then(response => response.json())
  .then(data => { 
    
    var data = data.data

    var options = {
    series: [{
    data: data.map(item => item.kaza_sayisi)
  }],
    chart: {
    type: 'bar',
    height: 350
  },

  title: {
    text: 'En Çok Kaza Olan Aylar (2021)  ',
    align: 'left'
  },
  
  plotOptions: {
    bar: {
      borderRadius: 2,
      horizontal: true,
    }
  },
  dataLabels: {
    enabled: false
  },
  xaxis: {
    categories: data.map(item => item.ay_adi)
  }
  };

  var chart = new ApexCharts(document.querySelector("#ay1"), options);
  chart.render(); 
});

fetch('http://localhost:3000/encok_ay_2022/')
  .then(response => response.json())
  .then(data => { 
    
    var data = data.data

    var options = {
    series: [{
    data: data.map(item => item.kaza_sayisi)
  }],
    chart: {
    type: 'bar',
    height: 350
  },

  title: {
    text: 'En Çok Kaza Olan Aylar (2022)  ',
    align: 'left'
  },
  
  plotOptions: {
    bar: {
      borderRadius: 2,
      horizontal: true,
    }
  },
  dataLabels: {
    enabled: false
  },
  xaxis: {
    categories: data.map(item => item.ay_adi)
  }
  };

  var chart = new ApexCharts(document.querySelector("#ay2"), options);
  chart.render(); 
});

fetch('http://localhost:3000/encok_tur_2021/')
  .then(response => response.json())
  .then(data => { 
    
    var data = data.data

    var options = {
    series: [{
    data: data.map(item => item.kaza_sayisi)
  }],
    chart: {
    type: 'bar',
    height: 350
  },

  title: {
    text: 'En Çok Kaza Olan Türler (2022)  ',
    align: 'left'
  },
  
  plotOptions: {
    bar: {
      borderRadius: 2,
      horizontal: true,
    }
  },
  dataLabels: {
    enabled: false
  },
  xaxis: {
    categories: data.map(item => item.kaza_turu)
  }
  };

  var chart = new ApexCharts(document.querySelector("#tur1"), options);
  chart.render(); 
});

fetch('http://localhost:3000/encok_tur_2022/')
  .then(response => response.json())
  .then(data => { 
    
    var data = data.data

    var options = {
    series: [{
    data: data.map(item => item.kaza_sayisi)
  }],
    chart: {
    type: 'bar',
    height: 350
  },

  title: {
    text: 'En Çok Kaza Olan Türler (2022)  ',
    align: 'left'
  },
  
  plotOptions: {
    bar: {
      borderRadius: 2,
      horizontal: true,
    }
  },
  dataLabels: {
    enabled: false
  },
  xaxis: {
    categories: data.map(item => item.kaza_turu)
  }
  };

  var chart = new ApexCharts(document.querySelector("#tur2"), options);
  chart.render(); 
});

