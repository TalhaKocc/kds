Apex.grid = {
    padding: {
      right: 0,
      left: 0
    }
  }
  
  Apex.dataLabels = {
    enabled: false
  }
  
  var randomizeArray = function (arg) {
    var array = arg.slice();
    var currentIndex = array.length, temporaryValue, randomIndex;
  
    while (0 !== currentIndex) {
  
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;
  
      temporaryValue = array[currentIndex];
      array[currentIndex] = array[randomIndex];
      array[randomIndex] = temporaryValue;
    }
  
    return array;
  }
  
  // data for the sparklines that appear below header area
  var sparklineData = [47, 45, 54, 38, 56, 24, 65, 31, 37, 39, 62, 51, 35, 41, 35, 27, 93, 53, 61, 27, 54, 43, 19, 46];
  
  // the default colorPalette for this dashboard
  //var colorPalette = ['#01BFD6', '#5564BE', '#F7A600', '#EDCD24', '#F74F58'];
  var colorPalette = ['#00D8B6','#008FFB',  '#FEB019', '#FF4560', '#775DD0', "#e7e96e", "#7ac7c4", "#8a9786", "#aa532e", "#adc34b", "#e83261", "#5fab04",]
  
  var spark1 = {
    chart: {
      id: 'sparkline1',
      group: 'sparklines',
      type: 'area',
      height: 160,
      sparkline: {
        enabled: true
      },
    },
    stroke: {
      curve: 'straight'
    },
    fill: {
      opacity: 1,
    },
    series: [{
      name: 'Sales',
      data: randomizeArray(sparklineData)
    }],
    labels: [...Array(24).keys()].map(n => `2018-09-0${n+1}`),
    yaxis: {
      min: 0
    },
    xaxis: {
      type: 'datetime',
    },
    colors: ['#DCE6EC'],
    title: {
      text: '$424,652',
      offsetX: 30,
      style: {
        fontSize: '24px',
        cssClass: 'apexcharts-yaxis-title'
      }
    },
    subtitle: {
      text: 'Sales',
      offsetX: 30,
      style: {
        fontSize: '14px',
        cssClass: 'apexcharts-yaxis-title'
      }
    }
  }
  
  var spark2 = {
    chart: {
      id: 'sparkline2',
      group: 'sparklines',
      type: 'area',
      height: 160,
      sparkline: {
        enabled: true
      },
    },
    stroke: {
      curve: 'straight'
    },
    fill: {
      opacity: 1,
    },
    series: [{
      name: 'Expenses',
      data: randomizeArray(sparklineData)
    }],
    labels: [...Array(24).keys()].map(n => `2018-09-0${n+1}`),
    yaxis: {
      min: 0
    },
    xaxis: {
      type: 'datetime',
    },
    colors: ['#DCE6EC'],
    title: {
      text: '$235,312',
      offsetX: 30,
      style: {
        fontSize: '24px',
        cssClass: 'apexcharts-yaxis-title'
      }
    },
    subtitle: {
      text: 'Expenses',
      offsetX: 30,
      style: {
        fontSize: '14px',
        cssClass: 'apexcharts-yaxis-title'
      }
    }
  }
  
  var spark3 = {
    chart: {
      id: 'sparkline3',
      group: 'sparklines',
      type: 'area',
      height: 160,
      sparkline: {
        enabled: true
      },
    },
    stroke: {
      curve: 'straight'
    },
    fill: {
      opacity: 1,
    },
    series: [{
      name: 'Profits',
      data: randomizeArray(sparklineData)
    }],
    labels: [...Array(24).keys()].map(n => `2018-09-0${n+1}`),
    xaxis: {
      type: 'datetime',
    },
    yaxis: {
      min: 0
    },
    colors: ['#008FFB'],
    //colors: ['#5564BE'],
    title: {
      text: '$135,965',
      offsetX: 30,
      style: {
        fontSize: '24px',
        cssClass: 'apexcharts-yaxis-title'
      }
    },
    subtitle: {
      text: 'Profits',
      offsetX: 30,
      style: {
        fontSize: '14px',
        cssClass: 'apexcharts-yaxis-title'
      }
    }
  }
  
  var monthlyEarningsOpt = {
    chart: {
      type: 'area',
      height: 260,
      background: '#eff4f7',
      sparkline: {
        enabled: true
      },
      offsetY: 20
    },
    stroke: {
      curve: 'straight'
    },
    fill: {
      type: 'solid',
      opacity: 1,
    },
    series: [{
      data: randomizeArray(sparklineData)
    }],
    xaxis: {
      crosshairs: {
        width: 1
      },
    },
    yaxis: {
      min: 0,
      max: 130
    },
    colors: ['#dce6ec'],
  
    title: {
      text: 'Total Earned',
      offsetX: -30,
      offsetY: 100,
      align: 'right',
      style: {
        color: '#7c939f',
        fontSize: '16px',
        cssClass: 'apexcharts-yaxis-title'
      }
    },
    subtitle: {
      text: '$135,965',
      offsetX: -30,
      offsetY: 100,
      align: 'right',
      style: {
        color: '#7c939f',
        fontSize: '24px',
        cssClass: 'apexcharts-yaxis-title'
      }
    }
  }
  
  
  var monthlyEarningsChart = new ApexCharts(document.querySelector("#monthly-earnings-chart"), monthlyEarningsOpt);
  
  
  var optionsArea = {
    chart: {
      height: 340,
      type: 'area',
      zoom: {
        enabled: false
      },
    },
    stroke: {
      curve: 'straight'
    },
    colors: colorPalette,
    series: [
      {
        name: "Blog",
        data: [{
          x: 0,
          y: 0
        }, {
          x: 4,
          y: 5
        }, {
          x: 5,
          y: 3
        }, {
          x: 9,
          y: 8
        }, {
          x: 14,
          y: 4
        }, {
          x: 18,
          y: 5
        }, {
          x: 25,
          y: 0
        }]
      },
      {
        name: "Social Media",
        data: [{
          x: 0,
          y: 0
        }, {
          x: 4,
          y: 6
        }, {
          x: 5,
          y: 4
        }, {
          x: 14,
          y: 8
        }, {
          x: 18,
          y: 5.5
        }, {
          x: 21,
          y: 6
        }, {
          x: 25,
          y: 0
        }]
      },
      {
        name: "External",
        data: [{
          x: 0,
          y: 0
        }, {
          x: 2,
          y: 5
        }, {
          x: 5,
          y: 4
        }, {
          x: 10,
          y: 11
        }, {
          x: 14,
          y: 4
        }, {
          x: 18,
          y: 8
        }, {
          x: 25,
          y: 0
        }]
      }
    ],
    fill: {
      opacity: 1,
    },
    title: {
      text: 'Aylık ciro',
      align: 'left',
      style: {
        fontSize: '18px'
      }
    },
    markers: {
      size: 0,
      style: 'hollow',
      hover: {
        opacity: 5,
      }
    },
    tooltip: {
      intersect: true,
      shared: false,
    },
    xaxis: {
      tooltip: {
        enabled: false
      },
      labels: {
        show: false
      },
      axisTicks: {
        show: false
      }
    },
    yaxis: {
      tickAmount: 4,
      max: 12,
      axisBorder: {
        show: false
      },
      axisTicks: {
        show: false
      },
      labels: {
        style: {
          colors: '#78909c'
        }
      }
    },
    legend: {
      show: false
    }
  }
  
  

  
  function trigoSeries(cnt, strength) {
    var data = [];
    for (var i = 0; i < cnt; i++) {
        data.push((Math.sin(i / strength) * (i / strength) + i / strength+1) * (strength*2));
    }
  
    return data;
  }
  
  // --------------------------------

  fetch('http://localhost:3000/kaza_aylar_2021/')
  .then(response => response.json())
  .then(data => {
    var data = data.data
    
    var options = {
      series: [{
        name: "Desktops",
        data: data.map(item => item.kaza_sayisi)
    }],
      chart: {
      height: 350,
      type: 'line',
      zoom: {
        enabled: false
      }
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: 'straight'
    },
    title: {
      text: 'Aylara Göre Kaza Sayısı (2021)',
      align: 'left'
    },
    grid: {
      row: {
        colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
        opacity: 0.5
      },
    },
    xaxis: {
      categories: data.map(item =>item.ay_adi)
    }
    };

    var chart = new ApexCharts(document.querySelector("#aylar2021"), options);
    chart.render();
  
  });

  fetch('http://localhost:3000/kaza_aylar_2022/')
  .then(response => response.json())
  .then(data => {
    var data = data.data
    
    var options = {
      series: [{
        name: "Desktops",
        data: data.map(item => item.kaza_sayisi)
    }],
      chart: {
      height: 350,
      type: 'line',
      zoom: {
        enabled: false
      }
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      curve: 'straight'
    },
    title: {
      text: 'Aylara Göre Kaza Sayısı (2022)',
      align: 'left'
    },
    grid: {
      row: {
        colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
        opacity: 0.5
      },
    },
    xaxis: {
      categories: data.map(item =>item.ay_adi)
    }
    };

    var chart = new ApexCharts(document.querySelector("#aylar2022"), options);
    chart.render();
  
  });  

  fetch('http://localhost:3000/kaza_arac_2021/')
  .then(response => response.json())
  .then(data => {
    var data = data.data
    
    var options = {
      series: [{
      name: 'deneme',
      data: data.map(item => item.kaza_sayisi)
    }],
      annotations: {
      points: [{
        x: 'Bananas',
        seriesIndex: 0,
        label: {
          borderColor: '#775DD0',
          offsetY: 0,
          style: {
            color: '#fff',
            background: '#775DD0',
          },
          text: 'deneme',
        }
      }]
    },
    chart: {
      height: 350,
      type: 'bar',
    },
    plotOptions: {
      bar: {
        borderRadius: 10,
        columnWidth: '50%',
      }
    },
    dataLabels: {
      enabled: false
    },
    stroke: {
      width: 2
    },
    
    grid: {
      row: {
        colors: ['#fff', '#f2f2f2']
      }
    },
    xaxis: {
      labels: {
        rotate: -45
      },
      categories: data.map(item =>item.arac_adi) ,
        
      
      tickPlacement: 'on'
    },
    yaxis: {
      title: {
        text: 'Kaza Arac Sayısı (2021)',
      },
    },
    fill: {
      type: 'gradient',
      gradient: {
        shade: 'light',
        type: "horizontal",
        shadeIntensity: 0.25,
        gradientToColors: undefined,
        inverseColors: true,
        opacityFrom: 0.85,
        opacityTo: 0.85,
        stops: [50, 0, 100]
      },
    }
    };

    var chart = new ApexCharts(document.querySelector("#araclar2021"), options);
    chart.render();
  
});

fetch('http://localhost:3000/kaza_arac_2022/')
.then(response => response.json())
.then(data => {
  var data = data.data
  
  var options = {
    series: [{
    name: 'deneme',
    data: data.map(item => item.kaza_sayisi)
  }],
    annotations: {
    points: [{
      x: 'Bananas',
      seriesIndex: 0,
      label: {
        borderColor: '#775DD0',
        offsetY: 0,
        style: {
          color: '#fff',
          background: '#775DD0',
        },
        text: 'deneme',
      }
    }]
  },
  chart: {
    height: 350,
    type: 'bar',
  },
  plotOptions: {
    bar: {
      borderRadius: 10,
      columnWidth: '50%',
    }
  },
  dataLabels: {
    enabled: false
  },
  stroke: {
    width: 2
  },
  
  grid: {
    row: {
      colors: ['#fff', '#f2f2f2']
    }
  },
  xaxis: {
    labels: {
      rotate: -45
    },
    categories: data.map(item =>item.arac_adi) ,
      
    
    tickPlacement: 'on'
  },
  yaxis: {
    title: {
      text: 'Kaza Arac Sayısı (2022)',
    },
  },
  fill: {
    type: 'gradient',
    gradient: {
      shade: 'light',
      type: "horizontal",
      shadeIntensity: 0.25,
      gradientToColors: undefined,
      inverseColors: true,
      opacityFrom: 0.85,
      opacityTo: 0.85,
      stops: [50, 0, 100]
    },
  }
  };

  var chart = new ApexCharts(document.querySelector("#araclar2022"), options);
  chart.render();

});


  fetch('http://localhost:3000/kaza_turler_2021/')
  .then(response => response.json())
  .then(data => {
    var data = data.data  
  
    var optionDonut = {
      chart: {
          type: 'donut',
          width: '100%',
          height: 400
      },
      dataLabels: {
        enabled: false,
      },
      plotOptions: {
        pie: {
          customScale: 0.8,
          donut: {
            size: '75%',
          },
          offsetY: 20,
        },
        stroke: {
          colors: undefined
        }
      },
      colors: colorPalette,
      title: {
        text: 'Türlere Göre Kaza Sayıları (2021)',
        style: {
          fontSize: '18px'
        }
      },
      series: data.map(item => item.kaza_sayisi),
      labels: data.map(item => item.kaza_tur_adi),
      legend: {
        position: 'left',
        offsetY: 80
      }
    }
    
    var donut = new ApexCharts(
      document.querySelector("#turler2021"),
      optionDonut
    )
    donut.render();   
});  
  
fetch('http://localhost:3000/kaza_turler_2022/')
.then(response => response.json())
.then(data => {
  var data = data.data  

  var optionDonut = {
    chart: {
        type: 'donut',
        width: '100%',
        height: 400
    },
    dataLabels: {
      enabled: false,
    },
    plotOptions: {
      pie: {
        customScale: 0.8,
        donut: {
          size: '75%',
        },
        offsetY: 20,
      },
      stroke: {
        colors: undefined
      }
    },
    colors: colorPalette,
    title: {
      text: 'Türlere Göre Kaza Sayıları (2022)',
      style: {
        fontSize: '18px'
      }
    },
    series: data.map(item => item.kaza_sayisi),
    labels: data.map(item => item.kaza_tur_adi),
    legend: {
      position: 'left',
      offsetY: 80
    }
  }
  
  var donut = new ApexCharts(
    document.querySelector("#turler2022"),
    optionDonut
  )
  donut.render();  
});  
 

  fetch('http://localhost:3000/kaza_isik_2021/')
  .then(response => response.json())
  .then(data => { 
    
    var data = data.data  
    
    var options = {
      series: [{
      data: data.map(item =>item.kaza_sayisi)
    }],
      chart: {
      type: 'bar',
      height: 350
    },
    plotOptions: {
      bar: {
        borderRadius: 4,
        horizontal: true,
      }
    },
    title: {
      text: 'Işık Türüne Göre Kazalar (2021)',
      align: 'left'
    },  
    dataLabels: {
      enabled: false
    },
    xaxis: {
      categories: data.map(item =>item.isik_adi)
    }
    };

    var chart = new ApexCharts(document.querySelector("#isik2021"), options);
    chart.render();
});  
  
fetch('http://localhost:3000/kaza_isik_2022/')
  .then(response => response.json())
  .then(data => { 
    
    var data = data.data  
    
    var options = {
      series: [{
      data: data.map(item =>item.kaza_sayisi)
    }],
      chart: {
      type: 'bar',
      height: 350
    },
    plotOptions: {
      bar: {
        borderRadius: 4,
        horizontal: true,
      }
    },
    title: {
      text: 'Işık Türüne Göre Kazalar (2022)',
      align: 'left'
    },  
    dataLabels: {
      enabled: false
    },
    xaxis: {
      categories: data.map(item =>item.isik_adi)
    }
    };

    var chart = new ApexCharts(document.querySelector("#isik2022"), options);
    chart.render();
});  
  
  fetch('http://localhost:3000/kaza_yerlesim_2021/')
  .then(response => response.json())
  .then(data => { 
    
    var data = data.data

    var options = {
    series: [{
    data: data.map(item => item.kaza_sayisi)
  }],
    chart: {
    type: 'bar',
    height: 350
  },

  title: {
    text: 'Yerleşim  Yerine GÖre Kazalar(2021)  ',
    align: 'left'
  },
  
  plotOptions: {
    bar: {
      borderRadius: 2,
      horizontal: true,
    }
  },
  dataLabels: {
    enabled: false
  },
  xaxis: {
    categories: data.map(item => item.yerlesim_adi)
  }
  };

  var chart = new ApexCharts(document.querySelector("#yerlesim2021"), options);
  chart.render(); 
});

fetch('http://localhost:3000/kaza_yerlesim_2022/')
  .then(response => response.json())
  .then(data => { 
    
    var data = data.data

    var options = {
    series: [{
    data: data.map(item => item.kaza_sayisi)
  }],
    chart: {
    type: 'bar',
    height: 350
  },

  title: {
    text: 'Yerleşim Yerine Göre Kazalar (2022)  ',
    align: 'left'
  },
  
  plotOptions: {
    bar: {
      borderRadius: 2,
      horizontal: true,
    }
  },
  dataLabels: {
    enabled: false
  },
  xaxis: {
    categories: data.map(item => item.yerlesim_adi)
  }
  };

  var chart = new ApexCharts(document.querySelector("#yerlesim2022"), options);
  chart.render(); 
});
  
  // a small hack to extend height in website sample dashboard

  
  
