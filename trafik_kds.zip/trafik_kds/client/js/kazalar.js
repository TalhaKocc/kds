// DATABASE 

document.addEventListener('DOMContentLoaded', function() {
  fetch('http://localhost:3000/getAll').then(response => response.json()).then(data => loadHTMLTable(data['data']));
});

document.querySelector('table tbody').addEventListener('click', function(event) {
  if (event.target.clasName === "delete-row-btn") {
      if (event.target.dataset.id);
  }
});

addBtn.onclick = function () {
  const turInput = document.querySelector('#kaza_tur_adi');
  const kaza_tur_adi = turInput.value;

  const aracInput = document.querySelector('#arac_adi');
  const arac_adi = aracInput.value;

  const ayInput = document.querySelector('#ay_adi');
  const ay_adi = ayInput.value;

  const isikInput = document.querySelector('#isik_adi');
  const isik_adi = isikInput.value;

  const yerlesimInput = document.querySelector('#yerlesim_adi')
  const yerlesim_adi = yerlesimInput.value;

  const yilInput = document.querySelector('#yil_adi')
  const yil_adi = yilInput.value; 

  turInput.value = "";
  aracInput.value = "";
  ayInput.value = "";
  isikInput.value = "";
  yerlesimInput.value = "";
  yilInput.value = "";

  fetch('http://localhost:3000/insert', {
    headers: {
      'Content-type': 'application/json'
    },
    method: 'POST',
    body: JSON.stringify({
      kaza_tur_adi : kaza_tur_adi,  
      arac_adi : arac_adi,
      ay_adi : ay_adi,
      isik_adi : isik_adi,
      yerlesim_adi : yerlesim_adi,
      yil_adi : yil_adi 

    })
  })
  .then(response => response.json())
  .then(data => insertRowIntoTable(data['data']));
}

searchBtn.onclick = function() {
  const searchValue = document.querySelector('#urun-ara').value;

  fetch('http://localhost:3000/search/' + searchValue)
  .then(response => response.json())
  .then(data => loadHTMLTable(data['data']));
}


function insertRowIntoTable(data) {
  const table = document.querySelector('table');
  const isTableData = table.querySelector('.no-data');
  
  let tableHtml = "<tr>";

  for (var key in data) {
    tableHtml += `<td>${data[key]}</td>`;
  }
  tableHtml += "</tr>";

  if (isTableData) {
    table.innerHTML = tableHtml;
  } else {
    const newRow = table.insertRow()
    newRow.innerHTML = tableHtml;
  }
}

function loadHTMLTable(data) {
  const table = document.querySelector('#table-body');

  if (data.length === 0) {
      table.innerHTML = "<tr><td class='no-data' colspan='5'>No Data</td></tr>";
      return;
  }

  let tableHtml = "";

  data.forEach(function ({kaza_id, kaza_tur_adi, arac_adi, ay_adi, isik_adi, yerlesim_adi, yil}) {
      tableHtml += "<tr>";
      tableHtml += `<td>${kaza_id}</td>`;
      tableHtml += `<td>${kaza_tur_adi}</td>`;
      tableHtml += `<td>${arac_adi}</td>`;
      tableHtml += `<td>${ay_adi}</td>`;
      tableHtml += `<td>${isik_adi}</td>`;
      tableHtml += `<td>${yerlesim_adi}</td>`;
      tableHtml += `<td>${yil}</td>`;
      tableHtml += "</tr>"
  });

  table.innerHTML = tableHtml;
}


// SIDEBAR TOGGLE

let sidebarOpen = false;
const sidebar = document.getElementById('sidebar');

function openSidebar() {
  if (!sidebarOpen) {
    sidebar.classList.add('sidebar-responsive');
    sidebarOpen = true;
  }
}

// URUN EKLE POPUP
function openPopup() {
  document.getElementById('popupContanier').style.display = 'flex';
}

function closePopup() {
  document.getElementById('popupContanier').style.display = 'none';
}

function closeSidebar() {
  if (sidebarOpen) {
    sidebar.classList.remove('sidebar-responsive');
    sidebarOpen = false;
  }
}
