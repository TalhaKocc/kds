form.addEventListener("submit", () => {
    const login = {
        username: username.value,
        password: password.value
    }
    fetch("/api/login", {
        method: "POST",
        body: JSON.stringify(login),
        headers: {
            "Content-type": "application/json"
        },
        redirect: 'follow' // Add this option to follow redirects
    })
    .then(res => {
        if (res.redirected) {
            // Redirect occurred, handle it appropriately
            window.location.href = res.url; // Manually redirect
            return; // Stop further processing
        }
        return res.json();
    })
    .then(data => {
        if (data.status == "error") {
            success.style.display = "none";
            error.style.display = "block";
            error.innerText = data.error;
        }
    })
    .catch(error => {
        console.error("Fetch error:", error);
        // Handle the error as needed
    });
})